﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadoraEnviosPaqueteria
{
    public partial class Form1 : Form
    {
        Envio envio = new Envio();
        public Form1()
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            label16.Text = "00.00";
            label15.Text = "00.00";
            label14.Text = "00.00";
            label13.Text = "00.00";
            label12.Text = "00.00";
            envio = new Envio();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("INDIQUE EL PESO DEL PAQUETE.");
                textBox1.Focus();
                return;
            }
            if (textBox2.Text == "")
            {
                MessageBox.Show("INDIQUE EL LARGO DEL PAQUETE.");
                textBox2.Focus();
                return;
            }
            if (textBox3.Text == "")
            {
                MessageBox.Show("INDIQUE EL ANCHO DEL PAQUETE.");
                textBox3.Focus();
                return;
            }
            if (textBox4.Text == "")
            {
                MessageBox.Show("INDIQUE LA ALTURA DEL PAQUETE.");
                textBox4.Focus();
                return;
            }
            if (textBox5.Text == "")
            {
                MessageBox.Show("INDIQUE LA DISTANCIA DEL ENVIO.");
                textBox5.Focus();
                return;
            }
            try
            {
                double peso = Convert.ToDouble(textBox1.Text);
                double largo = Convert.ToDouble(textBox2.Text);
                double ancho = Convert.ToDouble(textBox3.Text);
                double altura = Convert.ToDouble(textBox4.Text);
                double distancia = Convert.ToDouble(textBox5.Text);

                if (peso <= 0)
                {
                    MessageBox.Show("EL PESO DEBE SER MAYOR A 0");
                    textBox1.Focus();
                    return;
                }
                if (largo <= 0)
                {
                    MessageBox.Show("EL LARGO DEBE SER MAYOR A 0");
                    textBox2.Focus();
                    return;
                }
                if (ancho <= 0)
                {
                    MessageBox.Show("EL ANCHO DEBE SER MAYOR A 0");
                    textBox3.Focus();
                    return;
                }
                if (altura <= 0)
                {
                    MessageBox.Show("LA ALTURA DEBE SER MAYOR A 0");
                    textBox4.Focus();
                    return;
                }
                if (distancia <= 0)
                {
                    MessageBox.Show("LA DISTANCIA DEBE SER MAYOR A 0");
                    textBox5.Focus();
                    return;
                }

                envio.setPeso(peso);
                envio.setLargo(largo);
                envio.setAncho(ancho);
                envio.setAltura(altura);
                envio.setDistancia(distancia);

                envio.calcularPesovolum();
                label16.Text = envio.getPesovolum().ToString("N2") + " kg";
                envio.calcularPesototal();
                label15.Text = envio.getPesototal().ToString("N2") + " kg";
                envio.calcularCostototal();
                label14.Text = envio.getCostototal().ToString("N2") + " L";
                envio.calcularRecargodistan();
                label13.Text = envio.getRecargodistan().ToString("N2") + " L";
                envio.calcularTotal();
                label12.Text = envio.getTotal().ToString("N2") + " L";
            }
            catch (FormatException)
            {
                MessageBox.Show("Debe ingresar solamente números.");
            }
        }
    }
}
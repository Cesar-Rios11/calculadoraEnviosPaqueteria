﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadoraEnviosPaqueteria
{
    internal class Envio
    {
        //Atriutos

        private double peso;
        private double largo;
        private double ancho;
        private double altura;
        private double distancia;

        private double pesovolum;
        private double pesototal;
        private double costototal;
        private double recargodistan;
        private double total;

        //Metodo Constructor
        public Envio() { }

        //Metodos set

        public void setPeso(double peso)
        {
            if (peso > 0)
            {
                this.peso = peso;
            }
            else
            {
                MessageBox.Show("EL PESO DEBE SER MAYOR A 0");
            }
        }
        public void setLargo(double largo)
        {
            if (largo > 0)
            {
                this.largo = largo;
            }
            else
            {
                MessageBox.Show("EL LARGO DEBE SER MAYOR A 0");
            }
        }
        public void setAncho(double ancho)
        {
            if (ancho > 0)
            {
                this.ancho = ancho;
            }
            else
            {
                MessageBox.Show("EL ANCHO DEBE SER MAYOR A 0");
            }
        }
        public void setAltura(double altura)
        {
            if (altura > 0)
            {
                this.altura = altura;
            }
            else
            {
                MessageBox.Show("LA ALTURA DEBE SER MAYOR A 0");
            }
        }
        public void setDistancia(double distancia)
        {
            if (distancia > 0)
            {
                this.distancia = distancia;
            }
            else
            {
                MessageBox.Show("LA DISTANCIA DEBE SER MAYOR A 0");
            }
        }
        //Metodos get
        public double getPeso()
        {
            return peso;
        }
        public double getLargo()
        {
            return largo;
        }
        public double getAncho()
        {
            return ancho;
        }
        public double getAltura()
        {
            return altura;
        }
        public double getDistancia()
        {
            return distancia;
        }
        public double getPesovolum()
        {
            return pesovolum;
        }
        public double getPesototal()
        {
            return pesototal;
        }
        public double getCostototal()
        {
            return costototal;
        }
        public double getRecargodistan()
        {
            return recargodistan;
        }
        public double getTotal()
        {
            return total;
        }
        //Metodos de calculo
        public void calcularPesovolum()
        {
            pesovolum = (largo * ancho * altura) / 5000;
        }
        public void calcularPesototal()
        {
            if (peso > pesovolum)
            {
                pesototal = peso;
            }
            else
            {
                pesototal = pesovolum;
            }
        }
        public void calcularCostototal()
        {
            costototal = pesototal * 25;
        }
        public void calcularRecargodistan()
        {
            recargodistan = distancia * 2;
        }
        public void calcularTotal()
        {
            total = costototal + recargodistan;
        }   
    }
}